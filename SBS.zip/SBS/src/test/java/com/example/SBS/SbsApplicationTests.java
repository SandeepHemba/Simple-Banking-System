package com.example.SBS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbsApplicationTests {

	@Test
	void contextLoads() {
	}

}
