package com.example.SBS.Entity;

public enum AccountType {
    SAVINGS,
    CHECKING,
    CURRENT
}