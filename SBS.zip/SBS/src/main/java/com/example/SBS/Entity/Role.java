package com.example.SBS.Entity;

public enum Role {
    ADMIN,
    CUSTOMER
}
